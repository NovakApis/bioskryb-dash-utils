# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class App(Component):
    """An App component.
App provides Dash Design Kit styles
and an editable theme editor.
Wrap the layout of your application with `App`
and only use one `App` component per app.

App will re-style and theme your app with its own
opinionated CSS. If you don't wish to use this CSS,
you may use functional components such as `ddk.FullScreen`,
`ddk.Modal`, and `ddk.Graph` without wrapping your app's layout
with `ddk.App`.

Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    The children of the app's main layout, wrapped in the `ddk.App`
    container.

- id (string; optional):
    The ID of this component, used to identify Dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- className (string; optional):
    Optional user-defined CSS class for the App container.

- embedded (boolean; default False):
    Don't set opinionated styles that interfere with embedded apps
    Most style rules are scoped to apply only inside this ddk.App
    component But a few rules cannot be scoped because they apply to
    elements added separately to the DOM.

- notification_config (dict; optional)

    `notification_config` is a dict with keys:

    - border_radius (string; optional):
        The border-radius in 'px' of the Notification container.

    - displayed (boolean; optional):
        Whether or not Notifications in NotificationStore are
        displayed.

    - timeout (number | boolean; optional):
        The time in milliseconds for which the NotificationStore will
        remain onscreen. Default is 5*1000. -1 indicates no timeout.

    - type_display (list of booleans; optional):
        Array of booleans for filtering which types of array
        representing 'info', 'warn', 'danger'.

    - width (number | string; optional):
        Default width of the NotificationStore.

- show_editor (boolean; optional):
    Indicates whether \"EDIT THEME\" button in the bottom left corner
    should be visible on the App's page.

- show_undo_redo (boolean; default False):
    Display the undo_redo button.

- style (dict; optional):
    Optional user-defined CSS styles for the App container.

- theme (dict; optional):
    The theme's configuration. This configuration is editable with the
    theme editor. The theme editor will also auto-generate these
    variables for you in the \"Copy & Save\" tab.

- theme_dev_tools (boolean; default True):
    Theme the dev tools panel buttons with your DDK theme.

- use_mobile_viewport (boolean; default True):
    Optimize for mobile viewports on mobile. If set to `False`, mobile
    devices will display in desktop mode."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'dash_design_kit'
    _type = 'App'
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, theme=Component.UNDEFINED, show_editor=Component.UNDEFINED, theme_dev_tools=Component.UNDEFINED, embedded=Component.UNDEFINED, show_undo_redo=Component.UNDEFINED, notification_config=Component.UNDEFINED, use_mobile_viewport=Component.UNDEFINED, className=Component.UNDEFINED, style=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'embedded', 'notification_config', 'show_editor', 'show_undo_redo', 'style', 'theme', 'theme_dev_tools', 'use_mobile_viewport']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'embedded', 'notification_config', 'show_editor', 'show_undo_redo', 'style', 'theme', 'theme_dev_tools', 'use_mobile_viewport']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        super(App, self).__init__(children=children, **args)
