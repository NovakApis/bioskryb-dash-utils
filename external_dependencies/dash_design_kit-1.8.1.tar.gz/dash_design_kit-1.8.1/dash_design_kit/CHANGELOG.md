# Changelog
All notable changes to this project will be documented in this file.

This project adheres to [Semantic Versioning](http://semver.org/) and
the format of this `CHANGELOG` is based off of [keep a changelog](https://keepachangelog.com/en/1.0.0/).

## 1.8.1 2023-04-13

### Fixed
  - Fixed some CSS regressions with DCC Datepickers introduced in v1.8.0 [#1195]

## 1.8.0 2023-04-12

### Removed
  - Drop support for Internet Explorer [#1191]. Matching the policy of Dash as of `v2.7.0`, our build process now targets vendor-supported browsers released in the last 7 years. Currently this means ES2016 but over time this will naturally advance as older browser versions pass the 7-year threshold.
  - Raised the minimum compatible `dash` version from `v1.0.0` to `v1.6.1`

### Added
  - Support upcoming `dash-ag-grid v2.0` open-source release [#1191]

### Updated
  - Update `dash-table` and `dash-core-components` for Dash 2.9.2. This upgrades `plotly.js` to `v2.20.0`. [#1191]

### Fixed
  - Fixed several CSS leakages into the global scope, including Font Awesome and some `html body` resets [#1191]

## 1.7.0 2022-09-27
### Removed
  - Drop Python 2 support [#1178]

### Added
  - Support `dash-bootstrap-components` `v1.x` and `bootstrap` `v5.x`. [#1145]
  - Support `dash-daq` `v0.5.0`. [#1178]

### Updated
  - Updated dash-table and dash-core-components for Dash 2.6.2. This brings `Graph` improvements including built-in `MathJax` rendering of LaTeX-format math expressions, and upgrades `plotly.js` to `v2.13.3`, as well as various bugfixes in both `Graph` and `DataTable`. [#1154], [#1178]

## 1.6.8 2022-02-03
### Updated
  - Updated dash-table and dash-core-components for Dash 2.1. This brings over the `DataTable` improvements to `ddk`, including reordered props and making `columns` optional, for more efficient usage in simple cases. Also brings in `plotly.js` `v2.8.3` and all its new features such as smith charts. [#1154]

## 1.6.7 2022-01-18
### Fixed
  - Fix backgrounds in `DataCard` components, converting camel-cased keys in the `background_image` prop (`fullContent` and `linearGradient`) to the intended snake case (`full_content` and `linear_gradient`) while fixing their logic. [#1138]

## 1.6.6 2021-10-03
### Updated
  - Updated `dash_core_components` and `dash_html_components` to look for the Dash 2 imports `dash.dcc` and `dash.html`. DDK is still compatible with Dash 1.x but we recommend upgrading to Dash 2 [#1133]
  - Updated `ddk.Graph` to use the `dcc.Graph` base component in Dash Core Components `v2.0.0`, including `plotly.js` `v2.4.2`, via Dash `v2.0.0` [#1133]
  - Updated `ddk.DataTable` to use Dash Table `v5.0.0` from Dash `v2.0.0` [#1133]

### Added
  - `background_image` and `background_size` parameters in `DataCard`. `background_image` is a dict with keys: `full_content`, `linear_gradient`, and `value`. [#1135]

## 1.6.4 2021-09-04
### Fixed
  - Improved compatibility with `dash-daq` [#1126] [#1130] [#1131]

## 1.6.3 2021-07-23
### Fixed
  - Make CSS variables available outside the DDK container, so that popout elements can be styled [#1108]
  - Fix graph CSV downloads, and support Plotly.js v2.2 (including breaking changes in v2.0) [#1118]

## 1.6.2 2021-02-26
### Fixed
  - Fixed an issue where `medium`/`3px` outlines would be applied to Cards when the Box Shadow Containers preset was selected [#1078]
  - Fixed an issue where a defined `body_text` wouldn't be overridden by main presets (i.e. in the Presets tab), while `text` would be [#1078]
  - Fixed an issue in Safari where a `ddk.Title` component inside a `ddk.Header` wouldn't disappear when overflowing its container (e.g. on mobile viewports) [#1080]
  - Fixed a `TypeError` in box-shadow parsing when navigating the Containers > Header tab in the Theme Editor, resulting in a broken Theme Editor tab [#1086]
  - Improved the consistency of font and background colors of disabled controls inside `ddk.Header` components [#1085]
  - Fixed two bugs introduced in the DDK 1.6.0 prerelease:
    + `dcc.DatePickerSingle` label misalignment in a `ddk.ControlCard` [#1082]
    + overflow on `dcc.Dropdown` components given a `border-radius` with the `control_border.radius` theme property [#1084]

## 1.6.1 - 2021-02-11
### Added
  - Made Theme Editor CSS property (e.g. margin and padding) and color swatch text inputs "reactive"—now updating your theme as you type [#1061]

### Fixed
  - Fixed an issue with off-center `ddk.DataTable` checkboxes [#1051]
  - Fixed `ddk.CardFooter` backgrounds not respecting the `theme.report_background_content` color when inside reports [#1057]
  - Removed the in-line `ddk.ControlCard` padding default, which prevented Control Cards from respecting the `theme.card_padding` value [#1063]
  - Fixed a bug where multi-select `dcc.Dropdown` components would not expand when children of a `ddk.Modal` placed in a `ddk.Header` [#1066]
  - Fixed a bug where background color of the "Edit Theme" button would sporadically match the `theme.background_page` instead of contrasting with it [#1067]
  - Fixed various regressions introduced in the DDK 1.6.0 prerelease

### Updated
  - Updated `ddk.Graph` to use the `dcc.Graph` base component in Dash Core Components `v1.15.0`, including `plotly.js` `v1.58.4`, via Dash `v1.19.0` [#1058]
  - Updated `ddk.DataTable` to use Dash Table `v4.11.2` from Dash `v1.19.0` [#1058]

## 1.6.0 - 2020-12-07
### Added
  - Added full compatibility with the open-source [Dash Bootstrap Components](https://dash-bootstrap-components.opensource.faculty.ai/) (DBC)
    library by FacultyAI. DDK now includes Bootstrap CSS (no `external_stylesheets` argument needed) and themes all DBC components. [#1005]
  - Added full compatibility with the Dash DAQ (Data AcQuisition) library. Both light and dark DAQ components will be themed,
    and broken rendering of certain components (including `BooleanSwitch`, `PowerButton`, and `ToggleSwitch`). [#1010]
  - Added "Controls" tab to Theme Editor, along with new `theme` properties, in order to customize the appearance of
    input controls and buttons (`dcc.Dropdown`, `dcc.Input`, `dcc.DatePickerRange`, `dcc.DatePickerSingle`, `dcc.Textarea`, and `html.Button`)
    [#1018]

### Changed
  - Added a "close" button to opened/expanded `ddk.Modal` components [#1019]

### Updated
  - Updated `ddk.Graph` to use the `dcc.Graph` base component in Dash Core Components `v1.14.1`, including `plotly.js` `v1.58.2`, via Dash `v1.18.1` [#1027]
  - Updated `ddk.DataTable` to use Dash Table `v4.11.1` from Dash `v1.18.1` [#1027]

### Fixed
  - Fixed an issue with the `extendData` property of `ddk.Graph` that prevented
    graphs from updating correctly with the property value [#997]
  - Improved the rendering of selected radio buttons, where the inner circle would appear off-center [#1008]
  - Added missing `className` properties to `ddk.Header` and `ddk.DataCard` [#1011]
  - Fixed an issue with the `title` prop of `ddk.CardFooter` not responding to callbacks [#1012]
  - Better contrast for the "Edit Theme" button background/text color [#1017]
  - Fixes to control — label horizontal alignment on left-aligned (default) control labels [#1017]
  - Clearer indication of `disabled` controls with reduced opacity [#1017]
  - Lowering of the min-height of `dcc.Textarea` controls within `ddk.Header` components for consistent vertical margins [#1017]

## 1.5.4 - 2020-08-13
### Fixed
  - Fixed a 1.5.x regression in `html.Button` children of `ddk.Header` font sizes, and
    fixed background color consistency in `html.Button` and `dcc.Slider` children of `ddk.Header` [#993]

## 1.5.3 - 2020-08-10
### Fixed
  - Fixed un-themed DevTools after update in plotly/dash#1237 [#991]

## 1.5.2 - 2020-07-28
### Updated
  - Updated `ddk.Graph` to use the `dcc.Graph` backend in Dash Core Components `v1.10.2` from Dash `v1.14.0` [#931]
  - Updated `plotly.js` to `v1.54.7` [#931] [#942]
  - Updated `ddk.DataTable` to use Dash Table `v4.9.0` from Dash `v1.14.0` [#931]

## 1.5.1 - 2020-07-24
### Added
  - Added a new "light" theme as well as Plotly-branded light & dark themes to the Theme Editor Presets tab [#975]

### Fixed
  - Fixed a bug that blocked Dash Canvas components from rendering within `ddk.App` containers [#945]
  - Fixed a bug that prevented `parcats` trace types from rendering within `ddk.App` containers [#945]
  - Fixed an issue with too-tall `ddk.CardHeader` components that contained icons in OSX Safari and Chrome browsers [#967]
  - Fixed a problem with content and graph background consistency in "reversed" presets in the Theme Editor presets tab [#974]
  - Vertically centered non-`html.A`/`dcc.Link` components in a `ddk.Menu` by default [#968]
  - Hid "Notes" icon in Snapshot PDFs/`ddk.Report` pages with the query string `print=true` [#971]
  - Hid mobile notification button when 0 Notifications are present, and added a "warning" shadow when `danger` Notifications
    are present [#973]
  - Fixed `ddk.CollapsibleMenu` child caret icons to match text color when inside `ddk.Header` components [#972]
  - Added a warning that the Theme Editor is not currently compatible with Edge browsers below `v79` [#977]
  - Documentation: Widened example graphs in the Graphs chapter in Dash Enterprise Documentation [#970]

## 1.5.0 - 2020-06-25
### Added
  - Added a new Notification component [#860]
  - Added full set of documentation for Dash Design Kit for R at http://dash-gallery.plotly.host/dashr-design-kit [#722]
  - Added color, layout, and typography options for `ddk.Header` in Theme Editor and component properties [#898]
  - Allowed use of `id` property in `ddk.App`, allowing for its other properties, including `theme`, to be changed
    via callbacks [#934]
  - Added a wheel `.whl` build of Dash Design Kit [#933]
  - Documentation: Updated guide to custom fonts in the Typography chapter [#899]
  - Fixed layout for elements expanded with `ddk.FullScreen` and `ddk.Modal` for IE and Safari browsers, added
    hiding option for non-`FullScreen`-compatible browsers [#902]
  - Documentation: Set larger dimensions in the "Fullscreen graph resizing" section of the FullScreen & Modal chapter [#913]
  - Documentation: Clarified `ddk.ControlCard`/`ddk.ControlItem`/`ddk.Control` hierarchy [#918]
  - Documentation: Added an explanation of the differences between `ddk.Graph` and `ddc.Graph` dependencies in the Graphs
    chapter [#935]
  - Documentation: Added a new "Limitations" chapter [#936]

### Changed
  - Updated `plot.ly` references (in docs and source code) to new TLD `plotly.com` [#807]
  - Changed Theme Editor tabs for better UX & visibility [#892]

### Removed
  - Removed the unnecessary `dash_dangerously_set_inner_html` dependency [#932]

### Updated
  - Updated `ddk.Graph` to use the `dcc.Graph` backend in Dash Core Components `v1.10.1` from Dash `v1.13.3` [#931]
  - Updated `plotly.js` to `v1.54.5` [#931] [#942]
  - Updated `ddk.DataTable` to use Dash Table `v4.8.1` from Dash `v1.13.3` [#931]

### Fixed
  - Fixed a nested indentation error in Python theme dict [#858]
  - Fixed style mutation of expanded -> unexpanded non-`ddk.Card` elements that are targets of `ddk.FullScreen` [#871]
  - Fixed stringification of `target_id` in `ddk.FullScreen` and `ddk.Modal` components for compatibility with Dash v1.11
    (which includes Pattern-Matching Callbacks) [#903]
  - Fixed a bug with graph resizing in Safari `ddk.Report` components [#917]
  - Fixed `ddk.CardHeader` element alignment and overflow [#922]
  - Fixed a layout bug with non-`html.Li` and `html.A` elements like controls in `ddk.Menu` [#898]

## 1.4.1 - 2020-03-20
### Changed
  - Changed the filenames of async JS modules to use dashes (-)
    instead of tildes (~) [#824]
  - Changed the indentation of code in the "Save Theme" tab of the
    Theme Editor to use a more standard 4-space indentation, instead
    of 3 spaces. [#846]
  - Removed parent `<div>` wrappers of `ddk.Fullscreen` and `ddk.Modal` components,
    and added a new `ddk.Modal` and `ddk.CardHeader` property `modal_container_className`,
    in order to supply a `className` to modal container elements. [#851]

### Updated
  - Updated React to v16.13 [#841]
  - Updated `ddk.DataTable` to use `dash-table` `4.6.1` [#843]

### Fixed
  - Fixed an error with hidden overflow on long sub-menus (> 500px) [#828]
  - Fixed a CSS error with mobile menus on iOS/MacOS Safari/Chrome [#840]
  - Fixed a regression that prevented non `html.A`/`dcc.Link` components
    from rendering inside a menu. It is still recommended that only these
    components be `children` of `ddk.Menu` and `ddk.CollapsibleMenu`. [#842]
  - Fixed a regression where "inverse" themes (i.e. on even rows)
    in the "Presets" tab of the Theme Editor did not get applied properly [#847]
  - Documentation: fixed a typo in the "Fullscreen & Modal" chapter that referred
    to the nonexistent `hide_target_element` property, instead of `hide_target` [#848]
  - Fixed an Internet Explorer (IE) bug that provided inadequate padding for vertical
    `ddk.ControlCard`s [#800]
  - Fixed an IE bug that rendered `ddk.CardHeader`s containing `True` `modal`, `fullscreen`,
    or `copy` parameters with too much height [#801]
  - Fixed an IE11 bug that prevented rendering of `ddk.ControlItem`s within horizontal
    `ddk.ControlCard`s.

## 1.4.0 - 2019-01-21
### Added
  - A new API for changing common container layout options, including margin,
    padding, border, and background color, in the `ddk.Card`, `ddk.CardHeader`,
    and `ddk.Header` components. Also added a new GUI tab, Containers, for modifying
    these layout options globally [#644]
  - Theming of several more uncommon Plotly.js chart types that went previously unthemed
    with Dash Design Kit [#625]
  - A new build of Dash Design Kit for R [#692]
  - A warning of users who attempt to use `ddk.Header` within a `ddk.Page`
    component (i.e. within a `ddk.Report`) [#647]

### Changed
  - BREAKING: visual breaking change such that `ddk.DataCard` is consistent with
    the `ddk.Card` style in the default template. Visually noticeable differences
    are reduced inner `DataCard` padding and a non-rounded border radius. [#644]
  - BREAKING: visual breaking change such that `ddk.Card` components inside
    a `ddk.Page` that are adjacent to one or both side margins of the `Page` will have their
    adjacent margin(s) reset to 0. For example, a `ddk.Card` which is near the left edge of
    a `ddk.Page` will have its let margin set to 0. In order to override this
    behaviour, you may use the `style` argument in your `ddk.Card`, e.g.
   `ddk.Card(children=[...], style={'marginLeft': '10px'})`. This will
    preserve the left margin regardless of the `Card`'s position on the `Page`. [#536]
  - Changed the way Plotly.js is packaged; it is now bundled with this component
    instead of Dash Core Components and loaded lazily (i.e. as-needed) [#638]
  - Added a default 'standoff' parameter of '15px' to axis titles [#615]
  - The "Copy & Save" tab has been changed to "Save Theme" and included support
    for Javascript, Python, and R definitions [#684]

### Fixed
  - Fixed an issue with titles in `ddk.Header` not being hidden on mobile
    viewpoints [#685]
  - Fixed an issue with an upgrade to Dash Table that sporadically set lower
    specificity on DDK-themed tables [#653]
  - Documentation: fixed an issue with ellipsis overflow in enumerated Icon
    cards in the Icons chapter [#623]
  - Documentation: fixed a problem where line breaks were not escaped in the
    Migrating chapter [#621]
  - Fixed an issue where buttons would overflow their containers on smaller
    (e.g. mobile) widths [#608]
  - Fixed an issue where PX templates would override the default top graph margin
    in Dash Design Kit [#617]
  - Fixed an issue with Report fonts not persisting (overwritten by content fonts) [#606]
  - Added missing docstrings (component and prop descriptions) to the docs. [#599]
  - Added better colorscale support (colorscale interpolation, templates,
    theme variables) [#600]
  - Fixed an issue where `ddk.Table` components did not receive the
    `page_content_background` in `Page` [#525]

## 1.3.0 - 2019-10-02
### Changed
  - Changed the colorscale swatch picker in the Theme Editor Graph Colors > Colorway panel.
  - Removed unnecessary figure data keys when theming `ddk.Graph` components.
  - Changed the default map tiles in the docs, and removed the associated Mapbox token.
  - Included Font Awesome 5.11.2, so that the package is offline-only with no CDN requests.

### Fixed
  - Various improvements to the "Customize" tab in the Theme Editor Graph Colors > Colorway panel.
  - Fixed a memory leak in the theme editor that appended unnecessary CSS elements.
  components.
  - Fixed an issue where `ddk.Graph` `scattergl` points weren't being themed

### Updated
  - Updated Font Awesome to the latest version (5.11.2), adding many new icons.

## 1.2.3 - 2019-09-18
### Fixed
  - Fixed a bug that caused `ddk.Report` components to fail to render
    in Dash versions `>= 1.2.0`

## 1.2.2 - 2019-09-05
### Fixed
  - Fixed a bug that caused the theme editor to fail to render

## 1.2.1 - 2019-08-23
### Fixed
  - Missing "Report Background Content" swatch and
    unresponsive swatch backgrounds in the "Report & Page Default Styles" tab
### Changed
  - Changed default `report_background_content` color to `#FAFBFC`

## 1.2.0 - 2019-08-21
### Added
  - New `ddk.Report()` and `ddk.Page()` components, designed to integrate
  well with Dash Snapshot Engine. See the docs chapter under Arranging > Reports & Pages

### Changed
  - `ddk.Graph()` has been updated to match `dcc.Graph()` optimizations.
    See [#604](https://github.com/plotly/dash-core-components/pull/604) for details.

### Fixed
  - Bug where sub-keys in the generated docs (e.g. in the Reference chapter) were not appearing.

## 1.1.0 - 2019-08-07
### Added
  - Ability to set IDs on `ddk.CardHeader()` components.

### Changed
  - `ddk.DataTable` is updated to match the `dash_table.DataTable` `4.1.0` release.
  - The "Edit Theme" button's borders will be themed on hover.

### Fixed
  - Regression in arrow styling on open `dcc.Dropdown()` components.
  - Various performance improvements.

## 1.0.1 - 2019-07-25
### Fixed
  - Style bleed from `dash_table` CSS that affected `dcc.Dropdown()` components in `ddk.App()`
  - FullScreen and Modal graph dimensions (graph dimensions did not always account for `CardHeader` and `CardFooter`)
  - FullScreen and Modal performance — removed redundant renders

### Removed
  - `ddk._Markdown()` component, which was not part of the public API but was used for docs.
  The extra syntax highlighting functionality in this forked component is now part of `dcc.Markdown()`
  as of Dash `v1.0.0`.

## 1.0.0 - 2019-07-09
### Added
  - New component: `ddk.DataTable`. This is a "themed" version of `dash_table.DataTable`.
  It has the exact same syntax as `dash_table.DataTable`, the only difference is that
  its default styles match your `ddk` theme.
  - Automatic theming support for charts generated with [`plotly_express`](https://www.plotly.express/)
  - New component: `ddk.ControlItem()` (see "Changed" below)
  - New component: `ddk.CardHeader()` (see "Changed" below)
  - Compatibility with [Dash for R](https://github.com/plotly/dashr) (alpha)

### Changed
  - `dash_design_kit` depends on `dash>=1.0.0` and `dash_table>=4.0.0`. To
  use this version of Dash Design Kit, you will need to upgrade your codebase to
  a 1.x.x version of Dash first.
  [More info about migrating to `dash 1.0.0`](https://dash.plotly.com/dash-1-0-migration).
  - Previously, some examples had `style={'height': 'inherit'}` in the `ddk.Graph` component.
  This is no longer needed and, if supplied, may collapse the container. This rule
  should be removed when you upgrade.
  - 💥 `ddk.ControlCard` no longer accepts a list of `controls[]` as a parameter.
Instead of being supplied as the `control:` parameter in a list of dicts,
each control should be the single child of the new `ddk.ControlItem` component.
    - In turn, these `ddk.ControlItem` components should make up the `children[]` of
your `ControlCard`. `ddk.ControlItem` accepts the same parameters as each dict
previously did in a list of `controls=`, such as `label`, and `width`, but
instead of key/value pairs in a dict (e.g. 'label': 'First Control'), these should
be supplied as parameters of `ddk.ControlItem` (e.g. `label='First Control'`).

        For example, previously we had:

      ```python
      ddk.ControlCard(width=30, controls=[
          {
              'label': 'Engine',
              'control': dcc.Dropdown(
                   options=[
                       {'label': i, 'value': i}
                       for i in ['Rear', 'Front', 'Side']
                   ],
                   multi=True,
                   value=['Rear']
               ),
           },
           {
              'label': 'Thrusters',
              'control': dcc.Slider(
                   min=0,
                   max=10,
                   marks={
                       0: '0',
                       3: '3',
                       5: '5',
                       7.65: '7.65 °F',
                       10: '10'
                   },
                   value=5
               ),
           },
           {
               'label': 'Power',
               'control': dcc.Input(
                   value=50,
                   type='number'
               ),
           }
       ])
       ```

       This should now be:

       ```python
        ddk.ControlCard(width=30, children=[
            ddk.ControlItem(dcc.Dropdown(
                options=[
                    {'label': i, 'value': i}
                    for i in ['Rear', 'Front', 'Side']
                ],
                multi=True,
                value=['Rear']
            ), label='Engine'),

            ddk.ControlItem(dcc.Slider(
                min=0,
                max=10,
                marks={
                    0: '0',
                    3: '3',
                    5: '5',
                    7.65: '7.65 °F',
                    10: '10'
                },
                value=5
            ), label='Thrusters'),

            ddk.ControlItem(dcc.Input(
                value=50,
                type='number'
            ), label='Power')
        ])
       ```

       For more examples, see the [Controls](/controls) chapter (https://dash-gallery.plotly.host/dash-design-kit/controls).

  - 💥 `ddk.Card()` no longer accepts the `control` parameter. If you wish to use a control
in a Card, you must add your `dcc` control component
as an item in the `children[]` parameter of the new `ddk.CardHeader` component,
which in turn should be the first child of your `ddk.Card`.
This enables you to put a control alongside your title.
      - If you want the control on the bottom of the card, then use `ddk.CardFooter`.
        Previously, this was:

        ```python
        ddk.Card(
            title='City',
            control=dcc.Dropdown(
                id='city',
                options=[
                    {'label': i, 'value': i} for i in
                    ['Montreal', 'New York City', 'Los Angeles']
                ]
            ),
            control_position='bottom',
            width=50,
            children=ddk.Graph(figure={
                'data': [{
                    'x': [1, 2, 4, 5],
                    'y': [5, 9, 3, 1],
                    'line': {'shape': 'spline'}
                }]
            })
        )
        ```

        Now, this should be:

        ```python
        ddk.Card(
            width=50,
            children=[
                ddk.CardHeader(title='City'),
                ddk.Graph(figure={
                    'data': [{
                        'x': [1, 2, 4, 5],
                        'y': [5, 9, 3, 1],
                        'line': {'shape': 'spline'}
                    }]
                }),
                ddk.CardFooter(dcc.Dropdown(
                    id='city',
                    options=[
                        {'label': i, 'value': i} for i in
                        ['Montreal', 'New York City', 'Los Angeles']
                    ]
                ))
            ]
        )
        ```

  - 💥 `ddk.Card()` no longer accepts the `title`, `modal`, `modal_config`, or `fullscreen`
parameters. Instead, these arguments should be supplied to a `ddk.CardHeader()`, which should
be the first item in your `ddk.Card`'s `children[]`

For example, previously we had:

```python
ddk.Card(
    title='City',
    modal=True,
    control=dcc.Dropdown(
        id='city',
        options=[
            {'label': i, 'value': i} for i in
            ['Montreal', 'New York City', 'Los Angeles']
        ]
    ),
    width=50,
    children=ddk.Graph(
        figure={
            'data': [{
                'x': [1, 2, 4, 5],
                'y': [5, 9, 3, 1],
                'line': {'shape': 'spline'}
            }]
        }
    )
)
```

This should now be:
```python
ddk.Card(
    width=50,
    children=[
        ddk.CardHeader(
            title='City',
            modal=True,
            children=dcc.Dropdown(
                id='city',
                options=[
                    {'label': i, 'value': i} for i in
                    ['Montreal', 'New York City', 'Los Angeles']
                ]
            ),
        ),
        ddk.Graph(
            figure={
                'data': [{
                    'x': [1, 2, 4, 5],
                    'y': [5, 9, 3, 1],
                    'line': {'shape': 'spline'}
                }]
            }
        )
    ]
)
```

## 0.1.3 - 2019-05-21

### Changed
  - The `dash_design_kit.App()` container is now set to expand to the full height of the
    screen with `min-height: 100vh`. This can be turned off with `ddk.App(embedded=True)`.

## 0.1.2 - 2019-04-25
### Fixed
  - Bug that spawned too many WebGL contexts from user interaction, resulting in
    "oldest context will be lost" on Chrome/Firefox/Webkit browsers [#370]
    - Please note this issue is still unresolved in `dash >= 0.41.0` ([issue](https://github.com/plotly/dash-core-components/issues/535)). However, this version (`0.1.2`) will resolve the issue with `dash <= 0.40.0`.
  - Client-side console error from attempting to resize unmounted Graphs [#370]
  - Added missing dependency `dash_dangeously_set_inner_html` [#375]
  - More accurate print rendering of colors [#371]
  - Compatibility with `dash 0.42.0` [#382]
    - FullScreen and Modal compatibility
    - Updated theming for new version of dcc.DatePicker*
    - Performance regression fix for ddk.Graph() mouse events

## 0.1.1 - 2019-04-10
### Fixed
  - Bug that over-specified `ddk.Modal` CSS, which broke Modals that
    were not children of (i.e. wrapped by) `ddk.App` [#361]
  - `ddk.FullScreen` optimization logic prevented FullScreen graphs
    from resizing properly on `dash >= 0.40.0` [#363]
  - An import in `ddk.App` that broke `dash >= 0.41.0` compatibility due to
    the Dash upgrade to React v16 [#363]

## 0.1.0 - 2019-04-08

Warning: Dash Design Kit `<= 0.1.0` is not compatible with Dash `>= 0.41.0`
due to a breaking change in React v16

### Added
  - New `FullScreen` component: allows arbitrary components to be expanded to
    full-screen, including a UI icon for `Card` elements to be expanded [#333]
  - New `Modal` component: allows arbitrary components to be displayed in a
    "modal" container, at an optionally-specified size. Includes a UI icon
    for `Card` elements to be expanded [#333]
  - New `Graph` config option: allows for data from 'basic' chart types
    ('bar', 'scatter', and 'pie') to be downloaded as CSV data. [#345]
  - Ability to have "self-collapsing" `CollapsibleMenu` components that collapse
    when one of their siblings are selected [#353]

### Changed
  - Behaviour of `CollapsibleMenu` -- the "open/collapsed" state of these components
    will persist when their children or siblings are selected [#353]
  - The "undo/redo" button displayed on standard Dash apps can now be shown with
    a `show_undo_redo=True` argument in `ddk.App`. Previously, it was hidden. [#357]
  - All static CSS is now prefixed with `.ddk-container` -- allows for "functional"
    components such as `FullScreen` and `Modal` to be used without `ddk.App`.
    This prevents CSS from bleeding into unstyled/un-themed apps. [#351]

## 0.0.4 - 2019-03-27
### Added
  - Warning on invalid color code input in Theme Editor "Page Colors" section [#342]

### Fixed
  - Nested x-overflow scroll in Markdown `<pre>` elements [#336]
  - Regression from Dash 0.40.0 due to Menu & CollapsibleMenu logic [#348]

### Removed
  - Documentation has now been REMOVED from this package and split into
    a different package. Documentation is available in your DDS instance, or
    online at https://dash-gallery.plotly.host/dash-design-kit/ using the
    username and password supplied with your purchase. [#339]

## 0.0.3 - 2019-02-21
### Added
- Documentation: A few more pro-tips: vh sizing, theme variables, and
  markdown tips [#295]
- Documentation: Themed syntax highlighting of code snippets and source [#302]
- Documentation: Ability to choose Department with callback in USA Gov
  Analytics app [#297]
- Documentation: added title "Dash Design Kit" to main docs `ddk.Header` [#307]
- Added IE polyfill for `element.closest()` [#309]
- Added support for `var(--colorscale-i)` in Graph `figure` [#313]

### Fixed
  - Documentation: Removed x-overflow scroll in flights app [#307]
  - Fixed unwanted y-overflow scroll in `ddk.DataCard` values [#307]

### Changed
  - BREAKING CHANGE: `var(--trace-i)` and `var(--colorway_trace-i)` have been
  deprecated in favor of `var(--colorway-i)` [#313]
  - BREAKING CHANGE: `var(--colorscale_trace-i)` has been
  deprecated in favor of `var(--colorscale-i)` [#313]
  - Redesigned `ddk.Menu` children of `ddk.Header`; `ddk.CollapsibleMenu` in
  `ddk.Header` now opens on hover, not click [#307]
  - Documentation: main docs `ddk.Header` now uses `position: sticky` [#307]
  - Documentation: removed whitespace from "Templates and Sample Apps" +
  compressed content vertically, in order to avoid scrolling on smaller
  viewports [#312]

### Removed
  - Removed IE polyfill for `prepend()` (permanent fix in #308 via
    plotly/plotly.js#3491) [#309]
  - Removed references to events (removed in plotly/dash-renderer#114) [#309]
  - Removed `title: ''` workaround in graphs (permanent fix in #308 via
    plotly/plotly.js#3510) [#309]

### Updated
  - Documentation: upgraded `dash` from v`0.34.0` to `0.37.0` [#308]
  - Documentation: upgraded `dash-core-components` from v`0.43.0` to v`0.43.1` [#308]
  - Documentation: upgraded `dash-html-components` from v`0.13.4` to v`0.13.5` [#308]
  - Documentation: upgraded `dash-renderer` from v`0.16.0` to v`0.18.0` [#308]

## 0.0.2 - 2019-02-05
### Added
- Added back in `var(--trace-N)` CSS variables [#282]
- Documentation: Added references to `accent_positive` and `accent_negative` [#282]

### Fixed
- Documentation: scaled the footer image in the docs [#282]
- Documentation: Fixed various broken image links [#281]

### Changed
- Removed margins (`margin: {'l': 0, 'r': 0, 'b': 0, 't': 0}`) in `ddk.Graph`
components that contain `scattermapbox` traces. `scattermapbox`, unlike the
other chart types, doesn't have axes and so it doesn't need the extra room
padding the graph. This makes the `scattermapbox` graphs "full-bleed", which
looks especially nice when embedded in a `ddk.Card` component. [#265]
- Documentation: Various updates to the "flights" demo app. [#265]

## 0.0.1 - 2019-02-04
Initial release
