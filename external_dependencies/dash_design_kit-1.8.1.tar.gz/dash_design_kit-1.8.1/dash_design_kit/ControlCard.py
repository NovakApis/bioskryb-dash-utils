# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class ControlCard(Component):
    """A ControlCard component.
A layout component used for easily arranging groups of
controls (Dash Core Components) wrapped in ControlItems.

**Example Usage**
```
app.layout = ddk.App([
    ddk.ControlCard(
        children=[
              ddk.ControlItem(
                  dcc.Slider(
                      min=0,
                      max=10,
                      marks={
                          0: '0',
                          5: '5',
                          10: '10'
                      },
                      value=5
                  ),
                  label='Thrusters'
              ),
              ddk.ControlItem(
                  dcc.Input(
                      value=50,
                      type='number'
                  ),
                  label='Power'
              )
          ],
        orientation='horizontal',
        label_position='left',
    )
])
```

Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    The list of components, most commonly `ddk.ControlItem` items,
    that are children of the ControlCard container.

- id (string; optional):
    The ID of this component, used to identify Dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- card_hover (boolean; optional):
    Add a box-shadow to the card on hover.

- className (string; optional):
    Optional user-defined CSS class for the Block container.

- control_position (a value equal to: 'left', 'right', 'center', 'top'; default 'left'):
    The control alignment relative to the ControlCard container.

- label_position (a value equal to: 'top', 'left', 'bottom', 'right'; default 'top'):
    The positon of the label with respect to the control.

- label_style (dict; optional):
    Optional additional label CSS styles.

- label_text_alignment (a value equal to: 'left', 'right', 'center'; default 'left'):
    The horizontal label text alignment.

- margin (number; optional):
    Space (in pixels) surrounding the card.

- orientation (a value equal to: 'vertical', 'horizontal'; default 'vertical'):
    The orientation of the set of controls.

- padding (string | number; optional):
    The padding of (i.e. whitespace around) each individual control.
    Takes `%` int or string `Npx, Nem`, etc. values.

- rounded (boolean; optional):
    Applies a border-radius to the card's border.

- shadow_weight (a value equal to: 'light', 'medium', 'heavy'; optional):
    The appearance of the card's box-shadow, if set.

- style (dict; optional):
    Optional additional CSS styles. - If `width`, `padding`, or
    `margin` are supplied within `style`, then this will override the
    component-level `width`, `padding`, or `margin`.

- type (a value equal to: 'shadow', 'color', 'simple-border', 'flat'; optional):
    The appearance of the card's border.

- width (number; default 100):
    Number between 0 and 100 representing the width of the component
    with respect to its parent. - This is a percentage by default:
    `25` means take up 25% of the space. - Unless <1, in which it
    represents a decimal: 0.25 is the same as 25  Note that these
    units are different than the CSS `style` units where
    `style={'width': 25}` means _25 pixels_, not 25%.

- wrap (boolean; default True):
    Given a sum of control widths of horizontally-oriented controls
    >=100%, whether or not they should wrap onto the next line or stay
    in a single line. By default, if there are more than 5 (20%
    default width * 5 = 100%) controls, they will wrap."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'dash_design_kit'
    _type = 'ControlCard'
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, type=Component.UNDEFINED, shadow_weight=Component.UNDEFINED, card_hover=Component.UNDEFINED, rounded=Component.UNDEFINED, width=Component.UNDEFINED, margin=Component.UNDEFINED, orientation=Component.UNDEFINED, label_position=Component.UNDEFINED, label_text_alignment=Component.UNDEFINED, label_style=Component.UNDEFINED, control_position=Component.UNDEFINED, padding=Component.UNDEFINED, wrap=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'card_hover', 'className', 'control_position', 'label_position', 'label_style', 'label_text_alignment', 'margin', 'orientation', 'padding', 'rounded', 'shadow_weight', 'style', 'type', 'width', 'wrap']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'card_hover', 'className', 'control_position', 'label_position', 'label_style', 'label_text_alignment', 'margin', 'orientation', 'padding', 'rounded', 'shadow_weight', 'style', 'type', 'width', 'wrap']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        super(ControlCard, self).__init__(children=children, **args)
