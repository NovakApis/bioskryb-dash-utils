# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class DataCard(Component):
    """A DataCard component.
This component will render a styled DataCard with a label, large number, or
sublabel. Style includes handle (with optional icon) or spark trace
if data is provided.

Keyword arguments:

- id (string; optional):
    The ID of this component, used to identify Dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- background_color (string; optional):
    `background_color` is only used if `trace_y` is supplied. In which
    case, it will be the background color of the entire DataCard.

- background_image (dict; optional):
    `background_image` is only used if `trace_y` is not supplied.

    `background_image` is a dict with keys:

    - full_content (boolean; optional):
        If True, the background image will be applied to the entire
        datacard (Handle, DataCardContent).

    - linear_gradient (boolean; optional):
        If True, the value of the background_image will expect the CSS
        linear gradient parameters. Example: '0.25turn, #3f87a6,
        #ebf8e1, #f69d3c' See:
        https://developer.mozilla.org/en-US/docs/Web/CSS/gradient/linear-gradient().

    - value (string; optional):
        Value of the background image, can be a string of gradient
        parameters or a URL to a image.

- background_size (a value equal to: 'auto', 'contain', 'cover', 'inherit', 'initial', 'revert', 'unset'; default 'cover'):
    Background CSS value applicable when background_image is supplied.

- border_color (string; optional):
    The border color applied to the DataCard. Overrides
    theme.card_header_border.color.

- border_radius (string; optional):
    The border radius applied to the DataCard. Overrides
    theme.card_header_border.radius.

- border_style (string; optional):
    The border style applied to the DataCard. Overrides
    theme.card_header_border.style.

- border_width (string; optional):
    The border width applied to the DataCard. Overrides
    theme.card_header_border.width.

- box_shadow (string; optional):
    The box shadow(s) applied to the DataCard. Overrides
    theme.card_header_box_shadow.

- className (string; optional):
    Optional user-defined CSS class for the DataCard component.

- color (string; optional):
    Color modifies: - The background color of the \"handle\". If not
    supplied, then this will be the accent color. - If `trace_y` is
    supplied, then `color` is the color of the   graph's line (unless
    `background_color` is supplied, in which case   the trace line
    will be white). If `color` and `background_color`   aren't
    supplied, then the color of the line will be the theme's accent
    color.

- icon (string; optional):
    The font awesome icon name. This is the same as the `ddk.Icon`
    `icon_name` property.

- label (string; optional):
    The textual label that describes the label.

- margin (number; optional):
    Space (in pixels) surrounding the DataCard. Overrides
    theme.card_header_margin.

- padding (number; optional):
    Space (in pixels) on the inside of the DataCard, between the
    border and the edge of the content. Overrides theme.card_padding.

- parent_className (string; optional):
    Optional additional CSS class for the Block container of the
    DataCard.

- setProps (boolean | number | string | dict | list; optional):
    Dash-assigned callback that gets fired when the value changes.

- style (dict; optional):
    Style overrides to the outermost container.

- sub (number | string; optional):
    A smaller number to accompany `value`.

- text_color (string; optional):
    The color of the text. If this isn't supplied, then it will
    default to the theme's text color.

- trace_text (list; optional):
    The `text` data in the graph (appears on hover).

- trace_x (list; optional):
    The `x` data in the graph.

- trace_y (list; optional):
    The `y` data in the graph.

- value (number | string; optional):
    The large number.

- width (number; default 25):
    The width (in percentage) of the component with respect to its
    parent. This is the same type of unit that is used in `Block`,
    `Card`, & `ControlCard`."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'dash_design_kit'
    _type = 'DataCard'
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, className=Component.UNDEFINED, parent_className=Component.UNDEFINED, value=Component.UNDEFINED, label=Component.UNDEFINED, sub=Component.UNDEFINED, color=Component.UNDEFINED, trace_x=Component.UNDEFINED, trace_y=Component.UNDEFINED, trace_text=Component.UNDEFINED, icon=Component.UNDEFINED, background_color=Component.UNDEFINED, background_image=Component.UNDEFINED, background_size=Component.UNDEFINED, text_color=Component.UNDEFINED, margin=Component.UNDEFINED, padding=Component.UNDEFINED, box_shadow=Component.UNDEFINED, border_width=Component.UNDEFINED, border_style=Component.UNDEFINED, border_color=Component.UNDEFINED, border_radius=Component.UNDEFINED, style=Component.UNDEFINED, width=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'background_color', 'background_image', 'background_size', 'border_color', 'border_radius', 'border_style', 'border_width', 'box_shadow', 'className', 'color', 'icon', 'label', 'margin', 'padding', 'parent_className', 'setProps', 'style', 'sub', 'text_color', 'trace_text', 'trace_x', 'trace_y', 'value', 'width']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'background_color', 'background_image', 'background_size', 'border_color', 'border_radius', 'border_style', 'border_width', 'box_shadow', 'className', 'color', 'icon', 'label', 'margin', 'padding', 'parent_className', 'setProps', 'style', 'sub', 'text_color', 'trace_text', 'trace_x', 'trace_y', 'value', 'width']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(DataCard, self).__init__(**args)
