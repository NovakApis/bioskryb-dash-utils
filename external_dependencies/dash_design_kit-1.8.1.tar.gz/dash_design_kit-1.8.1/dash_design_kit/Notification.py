# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Notification(Component):
    """A Notification component.


Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    The list of components that are children of the Notification.

- id (string; optional):
    The ID of this component, used to identify Dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- className (string; optional):
    Optional user-defined CSS class for the Notification.

- collapsed (boolean; default False):
    Whether or not a notification is collapsed.

- displayed (boolean; default True):
    Whether or not a notification is displayed.

- style (dict; optional):
    Optional additional CSS styles. - If `width`, `padding`, or
    `margin` are supplied within `style`, then this will override the
    component-level `width`, `padding`, or `margin`.

- timeout (number; optional):
    The time in milliseconds for which the Notification will remain
    onscreen. Default is 5*1000. -1 indicates no timeout.

- title (string; optional):
    The title of the Notification.

- type (a value equal to: 'info', 'warn', 'danger'; default 'info'):
    Assigns a type which applies styling and can be used to filter.

- user_dismiss (boolean; default True):
    Applies an 'x' to the top right-hand corner  of the Notification
    that dismisses it on click."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'dash_design_kit'
    _type = 'Notification'
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, timeout=Component.UNDEFINED, displayed=Component.UNDEFINED, collapsed=Component.UNDEFINED, user_dismiss=Component.UNDEFINED, type=Component.UNDEFINED, title=Component.UNDEFINED, className=Component.UNDEFINED, style=Component.UNDEFINED, delete=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'collapsed', 'displayed', 'style', 'timeout', 'title', 'type', 'user_dismiss']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'collapsed', 'displayed', 'style', 'timeout', 'title', 'type', 'user_dismiss']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        super(Notification, self).__init__(children=children, **args)
