# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class PageHeader(Component):
    """A PageHeader component.
The PageHeader component allows you to customize the content and style
within the top margin of your page. A default PageHeader will be included
in each Page with the dimensions specified by the `page_margin.top`, which
can be set globally in the `ddk.Report` component or in an individual
Page component.

**Example Usage**
```
app.layout = ddk.App([
    ddk.Page([
        ddk.PageHeader([
            # Place a logo in the top margin
            ddk.Logo(src='https://dash.plotly.com/assets/images/logo-plotly.png'),
        ]),
        ddk.Graph(
            figure = my_figure,
        ),
    ]),
])
```

Keyword arguments:

- children (boolean | number | string | dict | list; optional):
    The list of components that are children of the PageHeader
    container.

- id (string; optional):
    The ID of this component, used to identify Dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- className (string; optional):
    Optional user-defined CSS class for the PageHeader container.

- style (dict; optional):
    Overrides the default (inline) styles for the this component."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'dash_design_kit'
    _type = 'PageHeader'
    @_explicitize_args
    def __init__(self, children=None, style=Component.UNDEFINED, className=Component.UNDEFINED, id=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'style']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'style']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        super(PageHeader, self).__init__(children=children, **args)
