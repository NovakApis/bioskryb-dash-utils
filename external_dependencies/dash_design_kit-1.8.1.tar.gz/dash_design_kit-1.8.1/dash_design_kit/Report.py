# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Report(Component):
    """A Report component.
The parent component for describing a report.
The contents of this component should be a set of `ddk.Page` components.

**Example Usage**
```
app.layout = ddk.App([
    ddk.Report(display_page_numbers=True, children=[
        ddk.Page([
            html.H1('Quarterly Earnings'),
            ddk.Block(width=50, margin=5, children=[
                ddk.Graph(figure=px.scatter(
                    ddk.datasets.bubble(),
                    x='x1', y='y1'
                ))
            ]),
            ddk.Block(width=50, margin=5, children=[
                ddk.Graph(figure=px.scatter(
                    ddk.datasets.bubble(),
                    x='x2', y='y2'
                ))
            ]),

            html.H2('Expected Returns'),
            ddk.Block(width=50, margin=5, children=[
                ddk.Graph(figure=px.scatter(
                    ddk.datasets.bubble(),
                    x='x2', y='y2'
                ))
            ]),
            ddk.Block(width=50, margin=5, children=[
                ddk.Graph(figure=px.scatter(
                    ddk.datasets.bubble(),
                    x='x1', y='y1'
                ))
            ]),
            ddk.PageFooter("Past Performance Is No Guarantee of Future Results."),
        ]),
    ])
])
```

Keyword arguments:

- children (boolean | number | string | dict | list; optional):
    The list of components that are children of the PageFooter
    container. These children should be of the type `ddk.Page`.

- id (string; optional):
    The ID of this component, used to identify Dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- className (string; optional):
    Optional user-defined CSS class for the Report container.

- display_page_numbers (boolean; optional):
    Indicates whether to display page numbers for all `ddk.Page
    children of this component.

- orientation (a value equal to: 'vertical', 'horizontal'; default 'vertical'):
    The orientation of the Page children of this Report container.

- page_margin (dict; optional):
    Set the (left, right, top, bottom) margin dimensions for all Page
    children of this Report container in units (`in`, `px`, `em`,
    etc.).

    `page_margin` is a dict with keys:

    - bottom (string; optional)

    - left (string; optional)

    - right (string; optional)

    - top (string; optional)

- page_margin_even (dict; optional):
    Set the (left, right, top, bottom) margin dimensions for all Page
    children of this Report container in units (`in`, `px`, `em`,
    etc.) with an even page number.

    `page_margin_even` is a dict with keys:

    - bottom (string; optional)

    - left (string; optional)

    - right (string; optional)

    - top (string; optional)

- page_margin_odd (dict; optional):
    Set the (left, right, top, bottom) margin dimensions for all Page
    children of this Report container in units (`in`, `px`, `em`,
    etc.) with an odd page number.

    `page_margin_odd` is a dict with keys:

    - bottom (string; optional)

    - left (string; optional)

    - right (string; optional)

    - top (string; optional)

- page_number_start_from (number; optional):
    The number to begin indexing the page count of the Page children
    of this Report container.

- page_style (dict; optional):
    Overrides the default (inline) styles for all `ddk.Page` children
    of this component.

- page_style_even (dict; optional):
    Overrides the default (inline) styles for all `ddk.Page` children
    of this component with an even page number.

- page_style_odd (dict; optional):
    Overrides the default (inline) styles for all `ddk.Page` children
    of this component with an odd page number.

- size (a value equal to: 'letter', 'legal', 'a4'; default 'letter'):
    The physical dimensions of the Page children of this Report
    container.

- style (dict; optional):
    Overrides the default (inline) styles for the this component.

- suppress_layout_exceptions (boolean; default False)"""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'dash_design_kit'
    _type = 'Report'
    @_explicitize_args
    def __init__(self, children=None, style=Component.UNDEFINED, page_style=Component.UNDEFINED, page_style_even=Component.UNDEFINED, page_style_odd=Component.UNDEFINED, display_page_numbers=Component.UNDEFINED, className=Component.UNDEFINED, id=Component.UNDEFINED, size=Component.UNDEFINED, orientation=Component.UNDEFINED, page_number_start_from=Component.UNDEFINED, page_margin=Component.UNDEFINED, page_margin_even=Component.UNDEFINED, page_margin_odd=Component.UNDEFINED, suppress_layout_exceptions=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'display_page_numbers', 'orientation', 'page_margin', 'page_margin_even', 'page_margin_odd', 'page_number_start_from', 'page_style', 'page_style_even', 'page_style_odd', 'size', 'style', 'suppress_layout_exceptions']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'display_page_numbers', 'orientation', 'page_margin', 'page_margin_even', 'page_margin_odd', 'page_number_start_from', 'page_style', 'page_style_even', 'page_style_odd', 'size', 'style', 'suppress_layout_exceptions']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        super(Report, self).__init__(children=children, **args)
