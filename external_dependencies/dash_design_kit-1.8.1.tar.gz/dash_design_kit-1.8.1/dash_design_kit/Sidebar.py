# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Sidebar(Component):
    """A Sidebar component.
A `Sidebar` is an app-level component used for displaying
a logo (`ddk.Logo`), a descriptive title of the app (`ddk.Title`),
and/or a set of links (`ddk.Menu`).

This can be used with our without a `ddk.Header`.

**Example Usage**
```
ddk.Sidebar(
    foldable=False,
    children=[
        ddk.Title('Economic Indicators'),
        ddk.Logo(src='/assets/my-logo.png'),
        ddk.Menu([
            ddk.CollapsibleMenu(
                title='Monetary Data',
                children=[
                    dcc.Link(
                        'Monetary Base',
                        href='/monetary-base'
                    ),
                    dcc.Link(
                        'Money Velocity',
                        href='/money-velocity'
                    ),
                    dcc.Link(
                        'Reserves',
                        href='/reserves'
                    ),
                    dcc.Link(
                        'Borrowings',
                        href='/borrowings'
                    )
                ]
            ),
            dcc.Link('Conditions', href='/conditions'),
            dcc.Link('Investment', href='/investments'),
            dcc.Link('Other', href='/other'),
        ])
    ]
)
```

Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    The contents of the Sidebar. This is frequently a list containing
    a `ddk.Logo`, a `ddk.Title`, and a `ddk.Menu`: ``` [
    ddk.Logo(src='/assets/logo.png'),     ddk.Title('Header Title'),
    ddk.Menu([         dcc.Link('Historical', href='/historical'),
    dcc.Link('Forecast', href='/forecast'), ] ``` but it can also
    contain arbitrary components like controls or buttons.

- id (string; optional):
    The ID of this component, used to identify Dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- className (string; optional):
    Optional user-defined CSS class for the Sidebar component.

- foldable (boolean; optional):
    If True, then the Sidebar can be collapsed. With `foldable`
    sidebars, we recommend using icons in your menu items so that the
    links are still visible when collapsed.

- style (dict; optional):
    The style object of the outermost div of the Sidebar. Use this to
    override the Sidebar's width (`{'maxWidth': '250px'}`) or the
    background color (`{'backgroundColor': 'white'}`)."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'dash_design_kit'
    _type = 'Sidebar'
    @_explicitize_args
    def __init__(self, children=None, className=Component.UNDEFINED, id=Component.UNDEFINED, foldable=Component.UNDEFINED, style=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'foldable', 'style']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'foldable', 'style']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        super(Sidebar, self).__init__(children=children, **args)
