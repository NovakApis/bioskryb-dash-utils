from pkg_resources import parse_version as _parse_version
from ._notification_manager import notification_manager

import os as _os
import sys as _sys
import json as _json

import dash as _dash

# noinspection PyUnresolvedReferences
from ._imports_ import *
from ._imports_ import __all__
from ._CopyText import _CopyText

from . import shortcuts
from . import datasets
from ._init_py_ddk_template import _setup_template

_setup_template()

if not hasattr(_dash, '__plotly_dash') and not hasattr(_dash, 'development'):
    print('Dash was not successfully imported. '
          'Make sure you don\'t have a file '
          'named \n"dash.py" in your current directory.', file=_sys.stderr)
    _sys.exit(1)

_basepath = _os.path.dirname(__file__)

_filepath = _os.path.abspath(_os.path.join(_basepath, 'package.json'))
with open(_filepath) as f:
    _package = _json.load(f)

_lock_filepath = _os.path.abspath(_os.path.join(_basepath, 'package-lock.json'))
with open(_lock_filepath) as f:
    _package_lock = _json.load(f)

__version__ = _package['version']

_deps = _package_lock['dependencies']

__dcc_version__ = _deps['dash-core-components']['version']
__dash_table_version__ = _deps['dash-table']['version']
__plotlyjs_version__ = _deps.get('plotly.js', _deps.get('plotly.js-dist-min'))['version']

_current_path = _os.path.dirname(_os.path.abspath(__file__))

_this_module = _sys.modules[__name__]

_async_resources = [
    'graph',
    'plotlyjs',
    'mathjax'
]

_js_dist = []

_js_dist.extend([{
    'relative_package_path': f'async-{async_resource}.js',
    'namespace': 'dash_design_kit',
    'async': True
} for async_resource in _async_resources])

_js_dist.extend([{
    'relative_package_path': f'async-{async_resource}.js.map',
    'namespace': 'dash_design_kit',
    'dynamic': True
} for async_resource in _async_resources])

_js_dist.extend([{
    'relative_package_path': 'dash_design_kit.min.js',
    'namespace': "dash_design_kit"
}, {
    'relative_package_path': 'dash_design_kit.min.js.map',
    'namespace': "dash_design_kit",
    'dynamic': True
}])

if _parse_version(_dash.__version__) < _parse_version("2.0.0") or "DDK_FORCE_BOOTSTRAP_4" in _os.environ:
    bootstrap_css = {
        "relative_package_path": "bootstrap4_build.css",
        "namespace": "dash_design_kit"
    }
else:
    bootstrap_css = {
        "relative_package_path": "bootstrap_build.css",
        "namespace": "dash_design_kit"
    }

_css_dist = [
    {
        "relative_package_path": "ddk-all.css",
        "namespace": "dash_design_kit"
    },
    bootstrap_css,
    {
        "relative_package_path": "fonts.css",
        "namespace": "dash_design_kit"
    },

    {
        "relative_package_path": "fa-ddk.css",
        "namespace": "dash_design_kit"
    },
]

for _component in __all__:
    setattr(locals()[_component], '_js_dist', _js_dist)
    setattr(locals()[_component], '_css_dist', _css_dist)
