from functools import wraps
from textwrap import dedent

def _merge(*args):
    merged = {}
    for arg in args:
        for key in arg:
            merged[key] = arg[key]
    return merged

def _omit(omitted_keys, d):
    return {k: v for k, v in d.items() if k not in omitted_keys}

def _relative_width(width, margin):
    if (type(width) is str):
        if ("px" or "%" in width):
            return 'calc({} - {}px)'.format(width, margin * 2)
        elif "auto" in width:
            return 'auto'
        else:
            return 'initial'
    else:
        if width is None:
            width = 20 # default to 20% width
        elif width <= 1:
            width = width * 100.
        return 'calc({}% - {}px)'.format(width, margin * 2)

def _id_not_accepted(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'id' in kwargs:
            raise Exception(dedent(
                '''
                `id` is not accepted in {component_name}.
                {component_name} is not directly compatible with Dash callbacks.
                However, if you pass components in as properties, you can
                assign _those_ components IDs and update _their_ properties
                through standard Dash callbacks.
                For example, consider `Card`. If you wanted to update the contents of the card when
                the control changes, pass ids into the children and the control:
                ```
                app.layout = ddk.Card(
                    control=dcc.Dropdown(
                        id='my-dropdown'   # the control has an id
                        options=[
                            # ...
                        ]
                    ),
                    children=html.Div(
                        id='my-output'      # the  _component_ inside children has an id
                    )
                )
                @app.callback(Output('my-output', 'children'), [Input('my-dropdown', 'value')])
                def update_output(value):
                    # ...
                ```
                tl;dr: {component_name} does not support `id` as a property.
                '''.format(component_name=func.__name__))
            )
        return func(*args, **kwargs)
    return wrapper
