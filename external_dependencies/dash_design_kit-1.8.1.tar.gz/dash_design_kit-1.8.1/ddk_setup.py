import json
import os
from setuptools import setup


with open(os.path.join('dash_design_kit', 'package.json')) as f:
    package = json.load(f)

setup(
    name='dash_design_kit',
    version=package["version"],
    author=package['author'],
    packages=[
        'dash_design_kit',
        'dash_design_kit.datasets',
        'dash_design_kit.images'
    ],
    include_package_data=True,
    license=package['license'],
    description=package['description'] if 'description' in package else package['name'],
    install_requires=['dash>=1.6.1', 'plotly>=3.10.0'],
    python_requires=">=3.6"
)
