# -*- coding: utf-8 -*-
import os
import sys
import time
import json
from urllib.request import urlopen

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from percy import percy_snapshot

import index

from .IntegrationTests import IntegrationTests

# Download geckodriver: https://github.com/mozilla/geckodriver/releases
# Or download chromedriver: https://chromedriver.chromium.org/downloads
# And add to path:
# export PATH=$PATH:/Users/chriddyp/Repos/dash-stuff/dash-integration-tests
#
# Uses percy.io for automated screenshot tests
# export PERCY_PROJECT=plotly/dash-design-kit
# export PERCY_TOKEN=(can be found at: https://percy.io/plotly/dash-design-kit/settings)

# URLs for pages on which Percy experiences difficulty snapshotting consistently
percy_problem_pages = [
    "http://localhost:8050/controls",
    "http://localhost:8050/fullscreen-modal",
    "http://localhost:8050/blocks",
    "http://localhost:8050/menus-headers-and-sidebars",
    "http://localhost:8050/extra-traces"
]
# Time to wait before screenshotting problematic pages for Percy
percy_wait_time = 45
class Tests(IntegrationTests):
    def setUp(self):
        self.schema = json.load(urlopen("https://raw.githubusercontent.com/plotly/plotly.js/master/dist/plot-schema.json"))

    def wait_for_element_by_css_selector(self, selector):
        start_time = time.time()
        while time.time() < start_time + 20:
            try:
                return self.driver.find_element_by_css_selector(selector)
            except NoSuchElementException as error:
                e = error
            time.sleep(1)

        raise e

    def snapshot(self, name, widths):
        if 'PERCY_TOKEN' in os.environ:
            python_version = sys.version.split(' ')[0]
            print('Percy Snapshot: Python v.{} with browser {} '.format(
                python_version,
                self.driver.capabilities['browserName']))
            percy_snapshot(driver=self.driver, name=name, widths=widths)

    def test_trace_difference(self):
        plotly_latest_traces = self.schema['traces'].keys()
        with open(os.path.join('src', 'lib', 'TRACE_TYPES.json'), 'r') as f:
            ddk_trace_types = json.loads(f.read())['TRACE_TYPES']

        set_difference = set(plotly_latest_traces).difference(set(ddk_trace_types))
        if bool(set_difference):
            raise Exception(
                'There are new traces in the latest plotly-js unlisted in DDK. New traces: \n{}'.format(
                    set_difference
                )
            )

    def test_data_keys(self):
        data_keys = [
            'geojson',
            'source'
        ]
        def crawl(obj):
            if isinstance(obj, list):
                for item in obj:
                    crawl(item)

            if isinstance(obj, dict):
                for key in obj:
                    if (isinstance(obj[key], dict) and (
                            obj[key].get('valType', '') == 'data_array' or
                            obj[key].get('arrayOk', '') is True) and
                            key not in data_keys and
                            'color' not in key):
                        data_keys.append(key)

                    crawl(obj[key])

        crawl(self.schema)
        with open(os.path.join('src', 'lib', 'DATA_KEYS.json'), 'r') as f:
            saved_data_keys = json.loads(f.read())['DATA_KEYS']
        if set(saved_data_keys) != set(data_keys):
            b_minus_a_set_difference = set(data_keys).difference(set(saved_data_keys))
            if b_minus_a_set_difference:
                set_difference = b_minus_a_set_difference
                set_descriptor = 'includes new'
            else:
                set_difference = set(saved_data_keys).difference(set(data_keys))
                set_descriptor = 'excludes old'
            raise Exception(
                'DATA_KEYS is out of date. New datakeys is: \n{}, \nwhich {} keys {}'.format(
                    json.dumps(sorted(data_keys), indent=2),
                    set_descriptor,
                    sorted(set_difference)
                )
            )

    def test_review_app(self):
        app = index.app
        self.startServer(app)
        try:
            WebDriverWait(self.driver, 20).until(
                EC.presence_of_element_located((By.ID, "container"))
            )
        except Exception as e:
            self.driver.save_screenshot('seleniumShot.png')
            raise e

        self.driver.save_screenshot('pre-shot.png')

        links = [
            a.get_property("href")
            for a in self.driver.find_elements_by_css_selector("a")
        ] + ['http://localhost:8050/visual-tests']

        # remove dupes
        links = list(set(links))

        print("List of paths to screenshot:")
        print(links)

        def visit_and_snapshot(href):
            print('Visiting {}'.format(href))
            try:
                self.driver.get(href)
            except Exception as e:
                print('Error visiting "{}"'.format(href))
                return

            try:
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located((By.ID, "container"))
                )
            except Exception as e:
                print('Error loading {}'.format(href))
                raise e

            self.driver.set_window_size(2000, 1200)
            print("Selenium driver window size:")
            print(self.driver.get_window_size())
            time.sleep(2)
            if (href in percy_problem_pages):
                print("Waiting for problem graph")
                time.sleep(percy_wait_time)
            try:
                WebDriverWait(self.driver, 30).until(
                    EC.invisibility_of_element_located((By.CSS_SELECTOR, '.dash-graph--pending'))
                )
            except Exception as e:
                print('Error with graph loading')

            self.snapshot(name=href + '&width=2000', widths=[2000])

            self.driver.set_window_size(1280, 1200)
            print("Selenium driver window size:")
            print(self.driver.get_window_size())
            time.sleep(2)
            if (href in percy_problem_pages):
                print("Waiting for problem graph")
                time.sleep(percy_wait_time)
            try:
                WebDriverWait(self.driver, 30).until(
                    EC.invisibility_of_element_located((By.CSS_SELECTOR, '.dash-graph--pending'))
                )
            except Exception as e:
                print('Error with graph loading')

            self.snapshot(name=href + '&width=1280', widths=[1280])

            # Browser width can't go < 490 (Chrome Linux(?) limitation)
            self.driver.set_window_size(490, 1200)
            print("Selenium driver window size:")
            print(self.driver.get_window_size())
            time.sleep(2)
            if (href in percy_problem_pages):
                print("Waiting for problem graph")
                time.sleep(percy_wait_time)
            try:
                WebDriverWait(self.driver, 30).until(
                    EC.invisibility_of_element_located((By.CSS_SELECTOR, '.dash-graph--pending'))
                )
            except Exception as e:
                print('Error with graph loading')

            self.snapshot(name=href + '&width=490', widths=[490])

            # Crawl apps in "Templates and Sample Apps"
            if href.rsplit('/', 1)[-1] == 'templates':
                sample_app_links = [
                    a.get_property("href")
                    for a in self.driver.find_elements_by_css_selector(".tile a")
                ]
                print("List of sample app paths to screenshot:")
                print(sample_app_links)
                self.driver.find_element_by_css_selector(".templates-tabs--tab:first-child").click()
                template_links = [
                    a.get_property("href")
                    for a in self.driver.find_elements_by_css_selector(".tile a")
                ]
                print("List of template app paths to screenshot:")
                print(template_links)
                # remove dupes and append lists
                app_links = list(set(sample_app_links + template_links))
                for link in app_links:
                    visit_and_snapshot(link)

            # Crawl apps in "tests"
            if href.rsplit('/', 1)[-1] == 'visual-tests':
                visual_test_links = [
                    a.get_property("href")
                    for a in self.driver.find_elements_by_css_selector(".tile a")
                ]
                print("List of test app paths to screenshot:")
                print(visual_test_links)
                for link in visual_test_links:
                    visit_and_snapshot(link)

            self.driver.back()

        for link in links:
            visit_and_snapshot(link)
